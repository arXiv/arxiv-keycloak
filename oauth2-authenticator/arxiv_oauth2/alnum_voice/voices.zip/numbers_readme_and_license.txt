Pack downloaded from Freesound
----------------------------------------

"Numbers 0-20"

This Pack of sounds contains sounds by the following user:
 - tim.kahn ( https://freesound.org/people/tim.kahn/ )

You can find this pack online at: https://freesound.org/people/tim.kahn/packs/4372/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this Pack
-------------------

  * 69169__Corsica_S__o_clock.aiff
    * url: https://freesound.org/s/69169/
    * license: Attribution 4.0
  * 69170__Corsica_S__oh.aiff
    * url: https://freesound.org/s/69170/
    * license: Attribution 4.0
  * 69168__Corsica_S__50.aiff
    * url: https://freesound.org/s/69168/
    * license: Attribution 4.0
  * 69167__Corsica_S__40.aiff
    * url: https://freesound.org/s/69167/
    * license: Attribution 4.0
  * 69166__Corsica_S__30.aiff
    * url: https://freesound.org/s/69166/
    * license: Attribution 4.0
  * 67758__Corsica_S__9.wav
    * url: https://freesound.org/s/67758/
    * license: Attribution 4.0
  * 67757__Corsica_S__8.wav
    * url: https://freesound.org/s/67757/
    * license: Attribution 4.0
  * 67755__Corsica_S__6.wav
    * url: https://freesound.org/s/67755/
    * license: Attribution 4.0
  * 67756__Corsica_S__7.wav
    * url: https://freesound.org/s/67756/
    * license: Attribution 4.0
  * 67753__Corsica_S__4.wav
    * url: https://freesound.org/s/67753/
    * license: Attribution 4.0
  * 67754__Corsica_S__5.wav
    * url: https://freesound.org/s/67754/
    * license: Attribution 4.0
  * 67751__Corsica_S__20.wav
    * url: https://freesound.org/s/67751/
    * license: Attribution 4.0
  * 67752__Corsica_S__3.wav
    * url: https://freesound.org/s/67752/
    * license: Attribution 4.0
  * 67750__Corsica_S__2.wav
    * url: https://freesound.org/s/67750/
    * license: Attribution 4.0
  * 67749__Corsica_S__19.wav
    * url: https://freesound.org/s/67749/
    * license: Attribution 4.0
  * 67747__Corsica_S__17.wav
    * url: https://freesound.org/s/67747/
    * license: Attribution 4.0
  * 67748__Corsica_S__18.wav
    * url: https://freesound.org/s/67748/
    * license: Attribution 4.0
  * 67746__Corsica_S__16.wav
    * url: https://freesound.org/s/67746/
    * license: Attribution 4.0
  * 67745__Corsica_S__15.wav
    * url: https://freesound.org/s/67745/
    * license: Attribution 4.0
  * 67744__Corsica_S__14.wav
    * url: https://freesound.org/s/67744/
    * license: Attribution 4.0
  * 67743__Corsica_S__13.wav
    * url: https://freesound.org/s/67743/
    * license: Attribution 4.0
  * 67741__Corsica_S__11.wav
    * url: https://freesound.org/s/67741/
    * license: Attribution 4.0
  * 67742__Corsica_S__12.wav
    * url: https://freesound.org/s/67742/
    * license: Attribution 4.0
  * 67740__Corsica_S__10.wav
    * url: https://freesound.org/s/67740/
    * license: Attribution 4.0
  * 67738__Corsica_S__0.wav
    * url: https://freesound.org/s/67738/
    * license: Attribution 4.0
  * 67739__Corsica_S__1.wav
    * url: https://freesound.org/s/67739/
    * license: Attribution 4.0


